package com.example.packagecomejemplofirstappfront.ui



import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.packagecomejemplofirstappfront.model.WeatherResponse
import com.example.packagecomejemplofirstappfront.network.WeatherService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class WeatherViewModel : ViewModel() {

    private val _weatherData = MutableStateFlow<WeatherResponse?>(null)
    val weatherData: StateFlow<WeatherResponse?> = _weatherData

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    fun getWeather(city: String) {
        if (city.isBlank()) {
            _error.value = "Por favor ingresa una ciudad"
            return
        }

        _isLoading.value = true
        _error.value = null

        viewModelScope.launch {
            try {
                // Simular delay de red
                kotlinx.coroutines.delay(1000)

                val response = WeatherService.getWeather(city)
                _weatherData.value = response
            } catch (e: Exception) {
                _error.value = "Error: ${e.message ?: "No se pudo obtener el clima"}"
            } finally {
                _isLoading.value = false
            }
        }
    }
}