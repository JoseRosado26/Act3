package com.example.packagecomejemplofirstappfront.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.packagecomejemplofirstappfront.model.WeatherResponse

@Composable
fun App() {
    val viewModel: WeatherViewModel = WeatherViewModel()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "🌤️ App del Clima",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        WeatherSearch(viewModel)

        Spacer(modifier = Modifier.height(32.dp))

        WeatherDisplay(viewModel)
    }
}

@Composable
fun WeatherSearch(viewModel: WeatherViewModel) {
    var city by remember { mutableStateOf("") }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth()
    ) {
        OutlinedTextField(
            value = city,
            onValueChange = { city = it },
            label = { Text("Ciudad") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = { viewModel.getWeather(city) },
            enabled = city.isNotEmpty(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Obtener Clima")
        }
    }
}

@Composable
fun WeatherDisplay(viewModel: WeatherViewModel) {
    val weatherData by viewModel.weatherData.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val error by viewModel.error.collectAsState()

    when {
        isLoading -> {
            CircularProgressIndicator()
            Text("Cargando...")
        }

        error != null -> {
            Text(
                text = error!!,
                color = MaterialTheme.colorScheme.error
            )
        }

        weatherData != null -> {
            WeatherCard(weatherData!!)
        }

        else -> {
            Text("Ingresa una ciudad")
        }
    }
}

@Composable
fun WeatherCard(weather: WeatherResponse) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = weather.city,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = weather.description,
                color = MaterialTheme.colorScheme.primary
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Información del clima
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Temperatura")
                Text("${weather.temperature}°C", fontWeight = FontWeight.Bold)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Humedad")
                Text("${weather.humidity}%", fontWeight = FontWeight.Bold)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Presión")
                Text("${weather.pressure} hPa", fontWeight = FontWeight.Bold)
            }
        }
    }
}