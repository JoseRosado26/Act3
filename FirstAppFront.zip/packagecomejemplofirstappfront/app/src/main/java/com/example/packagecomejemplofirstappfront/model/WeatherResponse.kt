package com.example.packagecomejemplofirstappfront.model

data class WeatherResponse(
    val temperature: Double,
    val humidity: Double,
    val pressure: Double,
    val description: String,
    val city: String
)