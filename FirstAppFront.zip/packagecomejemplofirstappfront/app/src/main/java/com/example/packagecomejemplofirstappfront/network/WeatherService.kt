package com.example.packagecomejemplofirstappfront.network

import com.example.packagecomejemplofirstappfront.model.WeatherResponse
import kotlin.random.Random

object WeatherService {

    // Datos simulados para diferentes ciudades
    private val cityWeatherData = mapOf(
        "madrid" to WeatherResponse(
            temperature = 22.5,
            humidity = 65.0,
            pressure = 1013.0,
            description = "Soleado",
            city = "Madrid"
        ),
        "barcelona" to WeatherResponse(
            temperature = 24.0,
            humidity = 70.0,
            pressure = 1012.0,
            description = "Parcialmente nublado",
            city = "Barcelona"
        ),
        "london" to WeatherResponse(
            temperature = 15.0,
            humidity = 80.0,
            pressure = 1015.0,
            description = "Lluvioso",
            city = "London"
        ),
        "new york" to WeatherResponse(
            temperature = 18.0,
            humidity = 75.0,
            pressure = 1010.0,
            description = "Nublado",
            city = "New York"
        ),
        "tokyo" to WeatherResponse(
            temperature = 20.0,
            humidity = 68.0,
            pressure = 1014.0,
            description = "Despejado",
            city = "Tokyo"
        )
    )

    fun getWeather(city: String): WeatherResponse {
        // Buscar ciudad exacta
        val lowerCity = city.lowercase()
        val exactMatch = cityWeatherData[lowerCity]

        if (exactMatch != null) {
            return exactMatch
        }

        // Si no encuentra coincidencia exacta, buscar parcial o generar datos aleatorios
        val partialMatch = cityWeatherData.entries.find {
            it.key.contains(lowerCity) || lowerCity.contains(it.key)
        }

        return partialMatch?.value ?: generateRandomWeather(city)
    }

    private fun generateRandomWeather(city: String): WeatherResponse {
        return WeatherResponse(
            temperature = (10.0 + Random.nextDouble(20.0)).round(1),
            humidity = (40.0 + Random.nextDouble(40.0)).round(1),
            pressure = (1000.0 + Random.nextDouble(30.0)).round(1),
            description = listOf("Soleado", "Nublado", "Parcialmente nublado", "Lluvioso", "Despejado").random(),
            city = city
        )
    }

    private fun Double.round(decimals: Int): Double {
        var multiplier = 1.0
        repeat(decimals) { multiplier *= 10 }
        return kotlin.math.round(this * multiplier) / multiplier
    }
}